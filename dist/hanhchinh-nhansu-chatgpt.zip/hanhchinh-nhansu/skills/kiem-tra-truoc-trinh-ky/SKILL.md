---
name: kiem-tra-truoc-trinh-ky
description: Rà soát văn bản trước khi trình lãnh đạo ký — chạy công cụ kiểm tra thể thức trên file Word (.docx) hoặc nội dung dán vào theo Nghị định 30/2020 (khổ, lề, phông, Quốc hiệu, số ký hiệu, ngày tháng, nơi nhận, ./., KT./TL./TUQ.), rồi soát nội dung (thẩm quyền ký, căn cứ còn hiệu lực, số tiền bằng chữ khớp số, ngày hiệu lực, nhất quán tên gọi, phụ lục, địa chỉ còn quận/huyện, viện dẫn luật cũ như BLLĐ 2012, Sở LĐTBXH), xếp lỗi 3 mức CHẶN / CẦN SỬA / GỢI Ý. Chỉ báo cáo, không sửa file gốc. Dùng khi người dùng nói "kiểm tra văn bản", "rà trước khi trình ký", "soát công văn này", "check quyết định", "văn bản này có sai gì không", "xem giúp tờ trình trước khi đưa sếp".
---

# Kiểm tra văn bản trước khi trình ký

Đọc trước: `references/nguyen-tac-chung.md`, `references/the-thuc-nd30.md`, `references/checklist-noi-dung.md`, `references/quy-dinh-lao-dong-2026.md` (văn bản nhân sự).

## Quy trình

**1. Lấy văn bản** – file .docx/.txt (đường dẫn), nội dung dán vào, hoặc file trên Drive (Google Drive / OneDrive) (xác nhận đúng tên, phiên bản mới nhất, người sửa cuối). Nhiều file trùng tên → liệt kê, hỏi.

**2. Rà hình thức bằng công cụ**
- Chạy `python3 scripts/cong_cu.py kiem_tra_the_thuc duong_dan=van-ban.docx` (hoặc `van_ban="..."` khi chỉ có nội dung dán vào).
- Văn bản nội bộ không dùng Quốc hiệu theo quy chế công ty → `co_quoc_hieu=false`.

**3. Rà nội dung bằng mắt** theo `references/checklist-noi-dung.md` (6 nhóm). Công cụ chỉ bắt lỗi hình thức; thẩm quyền, căn cứ, logic phải tự đọc.

**4. Phân mức** – mỗi lỗi đúng một mức:

| Mức | Khi nào | Ví dụ |
|---|---|---|
| 🔴 CHẶN | Gây hậu quả pháp lý/tài chính, văn bản có thể vô hiệu | Sai thẩm quyền ký; số tiền bằng chữ ≠ bằng số; căn cứ văn bản đã hết hiệu lực; quyết định kỷ luật thiếu bước bắt buộc; ngày hiệu lực trước ngày ký mà không có lý do |
| 🟡 CẦN SỬA | Sai thể thức, thiếu nhất quán | Lề, phông; ngày "5 tháng 3"; thiếu "Lưu: VT"; tên người viết hai kiểu |
| 🔵 GỢI Ý | Không sai nhưng nên tốt hơn | Câu dài, trích yếu dài, chưa có "./." |

Không dồn mọi thứ vào CHẶN.

**5. Báo cáo** (đúng thứ tự):
1. Kết luận 1 dòng: `Đủ điều kiện trình ký` / `Chưa đủ – N lỗi CHẶN`.
2. Bảng: `# | Mức | Vị trí (trích nguyên văn) | Vấn đề | Đề xuất sửa (câu chữ cụ thể)`.
3. **Không kiểm tra được** (ghi thẳng): căn cứ còn hiệu lực đến hôm nay? số liệu khớp sổ sách? người ký đang được ủy quyền hợp lệ? quy chế nội bộ chưa được cung cấp?
4. Hỏi có cần bản đã sửa không.

**6. Bản sửa** – chỉ khi người dùng yêu cầu; xuất văn bản mới có nhãn `[BẢN SỬA – CHƯA KÝ]`, liệt kê từng chỗ đã đổi. **Không ghi đè file gốc**; tạo file mới (ví dụ `..._da-sua.docx` qua `tao_van_ban_docx`).

## Nguyên tắc

- Không "sửa cho đẹp" mà không nói đã đổi gì.
- Không khẳng định văn bản "đúng luật"; chỉ kết luận về thể thức và tính nhất quán.
- Số tiền: chỉ đối chiếu nội bộ văn bản (bằng số ↔ bằng chữ, tổng ↔ các dòng); không xác nhận số đó đúng thực tế.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Google Drive** · **Gmail** · **Microsoft 365 (Outlook, OneDrive/SharePoint, Teams)**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Mở file cần kiểm tra trực tiếp từ Drive hoặc từ tệp đính kèm email khi người dùng chỉ tên file/thư.
2. Lưu báo cáo kiểm tra thành file mới cạnh file gốc (`..._Bao-cao-kiem-tra`), không sửa file gốc.
3. Cần gửi người soạn sửa: tạo nháp email liệt kê lỗi CHẶN / CẦN SỬA.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
