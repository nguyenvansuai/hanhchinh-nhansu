---
name: soan-van-ban-hanh-chinh
description: Soạn văn bản hành chính của doanh nghiệp đúng thể thức Nghị định 30/2020/NĐ-CP và xuất file Word chuẩn — công văn (đề nghị, phúc đáp, giải trình, đôn đốc, gửi cơ quan nhà nước, ngân hàng, đối tác), quyết định (bổ nhiệm, điều động, khen thưởng, thành lập ban, ban hành quy chế), tờ trình xin phê duyệt, thông báo, kế hoạch, báo cáo; tự chọn tên loại, viết căn cứ, trích yếu, nơi nhận, thẩm quyền ký (KT., TM., TL., TUQ.), đọc số tiền bằng chữ, xuất .docx A4 lề chuẩn Times New Roman. Dùng khi người dùng nói "soạn công văn", "viết quyết định", "làm tờ trình", "soạn thông báo", "viết kế hoạch", "làm báo cáo gửi sở", "phúc đáp công văn số...", "xuất file Word đúng thể thức".
---

# Soạn văn bản hành chính

Đọc trước: `references/nguyen-tac-chung.md`, `references/the-thuc-nd30.md`, `references/mau-noi-dung.md`.

## Bước 1 – Xác định đúng loại văn bản

| Người dùng muốn | Tên loại | Ký hiệu | Ghi chú |
|---|---|---|---|
| Trao đổi, đề nghị, trả lời, giải trình với bên ngoài | Công văn | Số/ABC-ĐV | Không có tên loại, có "V/v" |
| Ra quyết định về người, tổ chức, tiền, quy chế | Quyết định | Số/QĐ-ABC | Có căn cứ + Điều 1, 2, 3 |
| Xin cấp trên duyệt một việc | Tờ trình | Số/TTr-ABC | Kèm dự thảo quyết định nếu cần |
| Cho biết một việc đã quyết | Thông báo | Số/TB-ABC | |
| Lên kế hoạch thực hiện | Kế hoạch | Số/KH-ABC | |
| Báo kết quả | Báo cáo | Số/BC-ABC | |
| Chỉ đạo nội bộ ngắn | Thông báo / Công văn | | Doanh nghiệp không dùng "Chỉ thị" trừ khi quy chế có |

Người dùng gọi sai tên ("viết công văn quyết định bổ nhiệm") → chọn đúng loại và giải thích một câu.

## Bước 2 – Thu thông tin tối thiểu

Bắt buộc: cơ quan ban hành, người nhận/đối tượng, nội dung chính, người ký (chức vụ). Còn lại để `[CẦN BỔ SUNG]`.
Phúc đáp: phải có số, ngày, cơ quan ban hành văn bản được phúc đáp.

## Bước 3 – Soạn nội dung theo mẫu

Mẫu chi tiết từng loại: `references/mau-noi-dung.md`. Nguyên tắc chung:
- **Công văn**: mở đầu nêu lý do/căn cứ (1 đoạn) → nội dung chính (đánh số nếu nhiều ý; mỗi đề nghị trả lời được *ai làm gì, đến khi nào*) → kết thúc ("... đề nghị Quý Cơ quan xem xét, giải quyết./.").
- **Quyết định**: thẩm quyền ban hành (IN HOA) → căn cứ (văn bản trao thẩm quyền trước, văn bản làm cơ sở sau, "Theo đề nghị của..." cuối) → "QUYẾT ĐỊNH:" → Điều 1 nội dung → Điều 2 hiệu lực/quyền lợi → Điều cuối trách nhiệm thi hành.
- **Tờ trình**: sự cần thiết (số liệu thật) → nội dung đề nghị → kinh phí (bảng, số + chữ) → kiến nghị cụ thể.
- Số tiền: gọi `doc_so_thanh_chu` (hoặc `python3 scripts/cong_cu.py doc_so_thanh_chu so=1250000`).
- Hạn trong nội dung ("trong 05 ngày làm việc kể từ...") → tính ngày thật bằng `ngay_lam_viec` nếu người dùng cần ghi ngày cụ thể.

## Bước 4 – Rà và xuất file

1. Tự rà bằng `kiem_tra_the_thuc` (truyền `van_ban`) – sửa hết lỗi CHẶN, CẦN SỬA trước khi giao.
2. Hỏi người dùng có cần file Word không. Có → gọi `tao_van_ban_docx` (cần python-docx) với `noi_dung` là danh sách đoạn; đoạn "Điều n." tự in đậm.
3. **Không tự cấp số.** Để `Số:      /QĐ-ABC`; nhắc: ký xong mới cấp số bằng skill `so-van-ban-di-den`.

## Lưu ý doanh nghiệp Việt Nam

- Văn bản gửi **cơ quan nhà nước** (Sở Nội vụ, Thuế, BHXH, UBND xã/phường): theo đủ thể thức; tên cơ quan nhận ghi theo bộ máy mới (Sở Nội vụ thay Sở LĐTBXH; UBND xã/phường thay cấp huyện).
- Văn bản gửi **ngân hàng, đối tác**: công văn; đính kèm danh mục hồ sơ.
- Người ký không phải đại diện theo pháp luật → kiểm tra có giấy ủy quyền/quyết định phân quyền; ghi TUQ. hoặc KT. đúng.
- Quyết định nhân sự liên quan kỷ luật, chấm dứt HĐLĐ → chuyển sang skill `ky-luat-lao-dong` / `cham-dut-hop-dong` (có quy trình bắt buộc).

## Đầu ra

1. Văn bản hoàn chỉnh (có phần đầu theo bố cục 2 cột).
2. Bảng **Thông tin cần bổ sung**.
3. Kết quả tự rà thể thức (số lỗi còn lại).
4. File .docx (nếu người dùng yêu cầu) + nhắc bước cấp số, trình ký.
